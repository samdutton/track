WYSIWYP

A Chrome extension for 'what you see is what you get' printing of Google Maps.

.......................

How to use WYSIWYP




How does it work?

I don't know.


Feedback

Please send bug reports, comments or feature requests to samdutton@gmail.com.

For more information, please visit my website samdutton.com or my blog at samdutton.wordpress.com.

