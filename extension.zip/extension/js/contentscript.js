$(document).ready(function(){

var mediaElements = jQuery("video, audio").each(function(index, mediaElement){
	mediaElement.defaultTracks = {};
	jQuery(mediaElement).children("track").each(function(index, trackElement){
			if (trackElement.hasAttribute("default")){
				trackElement.addEventListener("load", function(){			
					mediaElement.defaultTracks[trackElement.kind] = trackElement.track;
				});
			}
	});
});

var trackKinds = ["captions", "metadata", "subtitles"];	
function changeLanguage(targetLanguage){	
	$("track").each(function(index, trackElement){
		trackElement.track.mode = 0 // first, turn off all tracks
	}
	
	// for each media element
	jQuery("video, audio").each(function(index, mediaElement){
		// for each track kind
		trackKinds.forEach(trackKind){
			// get the default track of this kind for the mediaElement
			var defaultTrack = mediaElement.defaultTracks[trackKind];
			var defaultMode = defaultTrack.mode;
			// if the mediaElement has a track of this kind for the targetLanguage
			var textTracks = mediaElement.textTracks;
			var isTrackFound = false;
			for (var i = 0; i != textTracks.length; ++i){
				var track = textTracks[i];
				if (track.kind === trackKind && track.language === targetLanguage){
					// set the found track mode to the default mode for this kind
					// in other words, turn it on!
					track.mode = defaultMode; 			
					isTrackFound = true;
					break;
				}
			}
			// if a track for the kind and target language wasn't found, build one
			if (!isTrackFound) {
				var newTrack = mediaElement.addTrack(trackKind);
				newTrack.language = targetLanguage;
				newTrack.mode = defaultMode; // set mode to default mode for this kind of track
				for (var j = 0; j != defaultTrack.cues.length; ++j){
					var cue = defaultTrack.cues[j];
					// asynchronously send requests to translate cues
					var googleTranslateURL = "https://www.googleapis.com/language/translate/v2?key=" + 
					// "AIzaSyAey8Y9zVKV0F7S3CKIUXoyCP-T-N-2NCk" + // 
					"AIzaSyCNwvUJo7bWWUMk7Z7bioTFvmWtHVXH2LY" + //
					"&source=" + cue.track.language + "&target=fr&q=" + cue.text;
					$.ajax({
						"url": googleTranslateURL,
						"context": {
							"newTrack": newTrack, 
							"cue": cue
						}		
					})
						.done(function(obj){ 
							var newTrack = this.newTrack;
							var cue = this.cue;
							// 'this' is the cue as set with the $.ajax() context parameter
							var translatedText = obj.data.translations[0].translatedText; 
							translatedText = $('<div/>').html(translatedText).text(); // convert entities
							// hacks to replace oddities if JSON values are used for cue text
							translatedText = translatedText.replace(/\"\.\"/g, '": "')
								.replace(/\.\. \»\:\« /g, '": "').replace(/\"\. /g, '"');
							newTrack.addCue(new TextTrackCue(translatedText, cue.startTime, cue.endTime, '', '', '', true));
						})
						.fail(function(obj) {
							console.log("error: ", obj); 
						});
				} // for each cue
 			} // if track not found		
		} 
	});



	$("video track").each(function(index, trackElement){
		var textTrack = trackElement.track; // gotcha!
		var textTrackLanguage = textTrack.language;
		for (var i = 0; i != textTrack.cues.length; ++i) {
			var cue = textTrack.cues[i];
		}
	});
}

changeLanguage("fr");
	
}); // $(document).ready()




//			if mediaElement has track[kind == trackKind && language == trackLanguage]
//				set that track as current
//			else 
//				defaultTrack = track[kind == trackKind && default == true]
//				newTrack = new TextTrack();
//				// build from defaultTrack
//				newTrack.language = trackLanguage;

// for each track
//		if (track.mode === 1) { // fire cuechange events but don't display
//			track.mode = 0;
//			track[kind == track.kind && language == trackLanguage].mode = 1;
//		else if (track.mode == 2) { // fire events and display 
//			track[kind == track.kind && language == trackLanguage].mode = 2;
//		}
/*
	for (var i = 0; i != trackKinds.length; ++i){
		var trackKind = trackKinds[i];
		// for each track with kind trackKind
			// if track.mode == 1 || track.mode == 2
		if (jQuery(this).has("track[kind = " + trackKind + "]").length){ 
			
//			console.log(trackKind, jQuery(this).children("track[kind = " + trackKind + "]"));
			if (jQuery(this).has("track[kind = " + trackKind + "]").length)){
			}
		}	
	}
});

*/
