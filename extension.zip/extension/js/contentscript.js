(function(){
"use strict";

// initially get these values from background page
var selectedLanguage; // set in changeLanguage() in response to popup message
var speakSubtitles; // set in response to message from popup
var request = {
	"type": "getSettings"
}

// !!!hack -- to give time for defaultTracks to be set
setTimeout(function(){
	chrome.extension.sendRequest(request, function(response){
		selectedLanguage = response.selectedLanguage;
		speakSubtitles = response.speakSubtitles;
		if (selectedLanguage !== ""){
			changeLanguage(selectedLanguage);
		}
	});
}, 500);

// get supported languages for popup
function handleGetLanguagesSuccess(obj){
	var request = {"type": "setSupportedLanguages"};
	request.supportedLanguages = obj.data.languages;
	chrome.extension.sendRequest(request, function(response){});
}

function handleGetLanguagesFailure(obj){
	console.log("Error getting list of supported languages: ", obj); 
}

// targetLanguage is the language of the language names (!), e.g. 'français' or 'french'
var targetLanguage = window.navigator.language.split("-")[0] || "en";

var googleTranslateURL = "https://www.googleapis.com/language/translate/v2/languages?key=" + 
	"AIzaSyCNwvUJo7bWWUMk7Z7bioTFvmWtHVXH2LY" + 
	"&target=" + targetLanguage;
$.ajax({
	"url": googleTranslateURL,
	"context": {
	}		
})
	.done(handleGetLanguagesSuccess)
	.fail(handleGetLanguagesFailure);


// change cue language
function handleTranslationSuccess(obj){ 
	var translatedText = obj.data.translations[0].translatedText; 
	translatedText = $('<div/>').html(translatedText).text(); // convert entities
	// hacks to replace oddities if JSON values are used for cue text
	translatedText = translatedText.replace(/\"\.\"/g, '": "')
		.replace(/\.\. \»\:\« /g, '": "').replace(/\"\. /g, '"').replace(/\"\.\:/g, '":').replace(/\.\ \»\.\:\«\ /g, '":"');
	// 'this' is the context object that was set with the $.ajax() context parameter
	this.cue.text = translatedText;
}

function handleTranslationFailure(obj){
	console.log("Error translating cue text: ", obj); 
}

function handleSubtitleCueChange(){
	if (!speakSubtitles){
		return;
	}
	// "this" is a textTrack
	var cue = this.activeCues[0]; // only deal with first active cue
	if (typeof cue === "undefined" || cue.text == "") {
		return;
	}
	var request = {};
	request.type = "speakSubtitles";
	request.language = selectedLanguage;	
	request.text = cue.text;
// 	request.text = encodeURI(cue.text);
	// can only call Google Translate from background page
	chrome.extension.sendRequest(request, function(response){});

}

function changeLanguage(targetLanguage){	
	selectedLanguage = targetLanguage;
	var trackElements = document.querySelectorAll("track");
	for (var i = 0; i !== trackElements.length; ++i){
		var trackElement = trackElements[i];
		var track = trackElement.track;
		var kind = trackElement.kind;
		// add listener for subtitle cue changes, for speaking subtitles 
		// !!! this should be moved out of here
		if (kind === "subtitles"){
			track.oncuechange = handleSubtitleCueChange; 
		}
		if (track.mode === 0 || track.language === targetLanguage){
			continue; // skip tracks that are disabled or already in the target language
		}
		var mediaElement = trackElement.parentElement; // a bit of a hack, but correct if code valid
		if (!mediaElement) { // but just in case...
			console.log("trackElement.parentElement is not mediaElement");
			continue;
		}
		var defaultTrack = mediaElement.defaultTracks[kind];
		for (var j = 0; j !== track.cues.length; ++j){
			// cue is for the current track
			var cue = track.cues[j];
			// defaultCue is the default cue stored for this kind of track for this media element 
			var defaultCueText = defaultTrack.cueTexts[j]; 
			// asynchronously send requests to translate cues
			var googleTranslateURL = "https://www.googleapis.com/language/translate/v2?key=" + 
			// "AIzaSyAey8Y9zVKV0F7S3CKIUXoyCP-T-N-2NCk" + // mine
			"AIzaSyCNwvUJo7bWWUMk7Z7bioTFvmWtHVXH2LY" + // g
			"&source=" + defaultTrack.language + "&target=" + targetLanguage + "&q=" + defaultCueText;
// 			console.log("googleTranslateURL: ", googleTranslateURL);
			$.ajax({
				"url": googleTranslateURL,
				"context": {
					"cue": cue
				}		
			})
				.done(handleTranslationSuccess)
				.fail(handleTranslationFailure);
		}
	}
}

// Send a message to the background page to clear any subtitles 
// queued for speaking in the audioURLs array
function clearSpokenSubtitleBacklog(){
	var request = {
		"type": "clearAudioURLs"
	}
	chrome.extension.sendRequest(request, function(response){});
}

// kick off track translation from language selected in popup
chrome.extension.onRequest.addListener(
    function(request, sender, sendResponse) {
		if (request.type === "setLanguage") {
			clearSpokenSubtitleBacklog();
			changeLanguage(request.language); 
		} else if (request.type === "toggleSpeakSubtitles") {
			clearSpokenSubtitleBacklog();
			speakSubtitles = request.speakSubtitles;			 
		} else {
			alert("Unknown request type in contentscript.js: " + request.type);
		}
		sendResponse({});  // allows request to be cleaned up -- otherwise it stays open
	}
);


$(document).ready(function(){

	// for each media element, add a defaultTracks property
	// which has a track object for each track kind
	// defaultTracks are used for translation
	jQuery("video, audio").each(function(index, mediaElement){
		mediaElement.defaultTracks = {};
		jQuery(mediaElement).children("track").each(function(index, trackElement){
				if (trackElement.hasAttribute("default")){
					trackElement.addEventListener("load", function(){
						var track = trackElement.track;
						console.log("track loaded: ", track.kind);
						var cueTexts = [];
						for (var i = 0; i != track.cues.length; ++i){
							cueTexts.push(track.cues[i].text);
						}	
						mediaElement.defaultTracks[trackElement.kind] = {
							"cueTexts": cueTexts,
							"kind": track.kind,
							"language": track.language
						};
					});
				}
		});
	});	
	
}); // $(document).ready()




})();